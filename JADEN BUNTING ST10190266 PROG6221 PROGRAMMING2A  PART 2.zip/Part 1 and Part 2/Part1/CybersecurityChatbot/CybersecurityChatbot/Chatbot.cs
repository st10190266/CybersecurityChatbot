﻿using System;
using System.Diagnostics;
using System.IO;
using System.Runtime.InteropServices;
using System.Threading;

namespace CybersecurityChatbot
{
    public class Chatbot
    {
        private readonly ResponseManager _responseManager;
        public string UserName { get; private set; } = "User";

        public Chatbot()
        {
            _responseManager = new ResponseManager();
        }

        public void Start()
        {
            PlayVoiceGreeting("greeting.wav");
            DisplayAsciiLogo();
            CaptureUserName();
            RunConversationLoop();
        }

        private void PlayVoiceGreeting(string filePath)
        {
            try
            {
                if (!File.Exists(filePath))
                {
                    Console.ForegroundColor = ConsoleColor.DarkYellow;
                    Console.WriteLine("[System Notice]: Voice greeting file missing. Skipping audio.");
                    Console.ResetColor();
                    return;
                }

                // Cross-Platform Audio Handling (Native afplay utility on macOS)
                if (RuntimeInformation.IsOSPlatform(OSPlatform.OSX))
                {
                    Process.Start("afplay", filePath);
                }
                else if (RuntimeInformation.IsOSPlatform(OSPlatform.Windows))
                {
                    // Fallback using System.Diagnostics process launch for Windows PowerShell audio player
                    Process.Start(new ProcessStartInfo("powershell", $"-c (New-Object Media.SoundPlayer '{filePath}').PlaySync();") { CreateNoWindow = true });
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[Audio Error]: Could not play greeting: {ex.Message}");
            }
        }

        private void DisplayAsciiLogo()
        {
            Console.Clear();
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine(@"
====================================================================
   ____ _____ ____  _____ _____  ____ _____ ____  _   _ _____ ___ 
  / ___| ____/ ___|| ____|  _ \| __ ) ____|  _ \| | | |_   _|_ _|
 | |   |  _| \___ \|  _| | |_) |  _ \  _| | |_) | | | | | |  | | 
 | |___| |___ ___) | |___|  _ <| |_) | |__|  _ <| |_| | | |  | | 
  \____|_____|____/|_____|_| \_\____/_____|_| \_\\___/  |_| |___|
                                                                  
                 CYBERSECURITY AWARENESS BOT v1.0                 
====================================================================");
            Console.ResetColor();
            Console.WriteLine();
        }

        private void CaptureUserName()
        {
            Console.ForegroundColor = ConsoleColor.Yellow;
            PrintTypingEffect("Hello! Welcome to the Cybersecurity Awareness Bot.");
            Console.Write("Please enter your name: ");
            Console.ResetColor();

            string? input = Console.ReadLine();
            if (!string.IsNullOrWhiteSpace(input))
            {
                UserName = input.Trim();
            }

            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine($"\nNice to meet you, {UserName}! How can I assist you today?");
            Console.WriteLine("--------------------------------------------------------------------");
            Console.ResetColor();
        }

        private void RunConversationLoop()
        {
            bool keepRunning = true;

            while (keepRunning)
            {
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.Write($"\n{UserName} > ");
                Console.ResetColor();

                string? userQuery = Console.ReadLine();

                if (userQuery?.Trim().ToLower() == "exit" || userQuery?.Trim().ToLower() == "quit")
                {
                    keepRunning = false;
                    Console.ForegroundColor = ConsoleColor.Cyan;
                    PrintTypingEffect($"Stay safe online, {UserName}! Goodbye.");
                    Console.ResetColor();
                    break;
                }

                string response = _responseManager.GetResponse(userQuery ?? string.Empty);

                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("Bot > ");
                PrintTypingEffect(response);
                Console.ResetColor();
            }
        }

        private void PrintTypingEffect(string message)
        {
            foreach (char c in message)
            {
                Console.Write(c);
                Thread.Sleep(15);
            }
            Console.WriteLine();
        }
    }
}