﻿using System;
using System.Collections.Generic;

namespace CybersecurityChatbot
{
    public class ResponseManager
    {
        // Automatic properties representing response configurations
        public string DefaultResponse { get; set; } = "I didn't quite understand that. Could you please rephrase or ask about passwords, phishing, or safe browsing?";
        public string UserMenu { get; set; } = "You can ask me about:\n  • Password Safety\n  • Phishing Attacks\n  • Safe Browsing\n  • My Purpose / How I work";

        private readonly Dictionary<string, string> _knowledgeBase;

        public ResponseManager()
        {
            _knowledgeBase = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase)
            {
                { "how are you", "I am running efficiently and ready to help you stay safe online!" },
                { "what is your purpose", "My purpose is to educate and assist you with best practices in cybersecurity." },
                { "what's your purpose", "My purpose is to educate and assist you with best practices in cybersecurity." },
                { "what can i ask you about", UserMenu },
                { "password safety", "Use strong, unique passwords with at least 12 characters, including upper/lowercase letters, numbers, and symbols. Never reuse passwords!" },
                { "passwords", "Use strong, unique passwords with at least 12 characters, including upper/lowercase letters, numbers, and symbols. Never reuse passwords!" },
                { "phishing", "Phishing attempts often use urgent language or suspicious links. Always verify sender email addresses before clicking any links or attachments." },
                { "safe browsing", "Ensure websites use HTTPS, keep your browser updated, avoid public Wi-Fi for sensitive transactions, and use an ad-blocker." }
            };
        }

        public string GetResponse(string input)
        {
            // Input Validation
            if (string.IsNullOrWhiteSpace(input))
            {
                return "It looks like you submitted an empty message. Please type a question!";
            }

            string cleanInput = input.Trim().ToLower();

            foreach (var key in _knowledgeBase.Keys)
            {
                if (cleanInput.Contains(key))
                {
                    return _knowledgeBase[key];
                }
            }

            return DefaultResponse;
        }
    }
}