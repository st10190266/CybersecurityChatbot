﻿using System;
using System.Collections.Generic;

namespace CybersecurityChatbot
{
    class Program
    {
        static void Main(string[] args)
        {
            Logo logo = new Logo();
            ChatbotEngine engine = new ChatbotEngine();

            Console.WriteLine(logo.GetAsciiArt());
            logo.PlayGreeting();

            Console.WriteLine("Bot: Hello! Welcome to the Cybersecurity Awareness Chatbot.");
            Console.WriteLine("Bot: Type your questions regarding passwords, phishing, privacy, or scams (type 'exit' to quit).\n");

            while (true)
            {
                Console.Write("You: ");
                string userInput = Console.ReadLine();

                if (string.IsNullOrWhiteSpace(userInput)) continue;
                if (userInput.Equals("exit", StringComparison.OrdinalIgnoreCase))
                {
                    Console.WriteLine("\nBot: Stay safe online! Goodbye.");
                    break;
                }

                string response = engine.ProcessInput(userInput);
                Console.WriteLine($"\nBot: {response}\n");
            }
        }
    }

    public class Logo
    {
        public string GetAsciiArt()
        {
            return @"
   ___      _               _   ___                  ___         _   
  / __\_   | |__   ___ _ __| |_/ __ \___ _   _ _ __  | __\_   _| |_ 
 / /  / _ \| '_ \ / _ \ '__| __/ /  // _ \ | | | '__| |  _| | | | __|
/ /___ (_) | |_) |  __/ |  | |_/ /_//  __/ |_| | |    | |___| |_| | |_ 
\____/\___/|_.__/ \___|_|   \__\___/ \___|\__,_|_|    \____/ \__,_|\__|
            ";
        }

        public void PlayGreeting()
        {
            // Audio greeting omitted on macOS since SoundPlayer is Windows-specific
        }
    }

    public class ChatbotEngine
    {
        private readonly Dictionary<string, List<string>> _knowledgeBase;
        private readonly Random _random;

        public string UserName { get; set; }
        public string FavoriteTopic { get; set; }
        public string CurrentTopic { get; set; }

        public ChatbotEngine()
        {
            _random = new Random();
            _knowledgeBase = new Dictionary<string, List<string>>(StringComparer.OrdinalIgnoreCase)
            {
                {
                    "password", new List<string> {
                        "Make sure to use strong, unique passwords for each account. Avoid using personal details in your passwords.",
                        "A robust password should be at least 12 characters long and combine uppercase letters, lowercase letters, numbers, and symbols.",
                        "Consider using a reputable password manager to securely store and generate complex credentials."
                    }
                },
                {
                    "scam", new List<string> {
                        "Online scams often create a false sense of urgency. Always verify the source before clicking links or sending money.",
                        "If an offer sounds too good to be true, it usually is. Guard your personal and financial information closely."
                    }
                },
                {
                    "privacy", new List<string> {
                        "Regularly review the privacy and security settings on all your social media and financial accounts.",
                        "Limit the amount of personal information you share publicly online to protect your digital footprint."
                    }
                },
                {
                    "phishing", new List<string> {
                        "Be cautious of unsolicited emails asking for personal information. Scammers often disguise themselves as trusted organizations.",
                        "Check sender email addresses carefully for subtle typos or suspicious domains before interacting with messages.",
                        "Never click on unexpected attachments or links from unknown senders."
                    }
                }
            };
        }

        public string ProcessInput(string input)
        {
            string lowerInput = input.ToLower();

            string sentimentResponse = CheckSentiment(lowerInput);
            if (sentimentResponse != null) return sentimentResponse;

            if (lowerInput.Contains("my name is") || lowerInput.Contains("i am "))
            {
                string[] parts = input.Split(new[] { "is", "am" }, StringSplitOptions.None);
                if (parts.Length > 1)
                {
                    UserName = parts[1].Trim().TrimEnd('.');
                    return $"Nice to meet you, {UserName}! How can I help you stay safe online today?";
                }
            }

            if (lowerInput.Contains("give me another tip") || lowerInput.Contains("explain more"))
            {
                if (!string.IsNullOrEmpty(CurrentTopic) && _knowledgeBase.ContainsKey(CurrentTopic))
                {
                    return GetRandomResponse(CurrentTopic);
                }
                return "What specific cybersecurity topic would you like to explore further?";
            }

            foreach (var kvp in _knowledgeBase)
            {
                if (lowerInput.Contains(kvp.Key))
                {
                    CurrentTopic = kvp.Key;
                    if (lowerInput.Contains("interested in") || lowerInput.Contains("love"))
                    {
                        FavoriteTopic = kvp.Key;
                        return $"Great! I'll remember that you're interested in {FavoriteTopic}.";
                    }

                    string response = GetRandomResponse(kvp.Key);
                    if (!string.IsNullOrEmpty(FavoriteTopic) && kvp.Key == FavoriteTopic)
                    {
                        return $"As someone interested in {FavoriteTopic}, you should note: {response}";
                    }
                    return response;
                }
            }

            return "I'm not sure I understand. Can you try rephrasing or ask about passwords, scams, privacy, or phishing?";
        }

        private string CheckSentiment(string input)
        {
            if (input.Contains("worried") || input.Contains("scared") || input.Contains("anxious"))
            {
                return $"It's completely understandable to feel that way. Scammers can be convincing. Tip: {GetRandomResponse("scam")}";
            }
            return null;
        }

        private string GetRandomResponse(string topic)
        {
            var responses = _knowledgeBase[topic];
            return responses[_random.Next(responses.Count)];
        }
    }
} 