﻿using System.Configuration;
using System.Data;
using System.Windows;

namespace Cybersecurity_Awareness_Bot
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
    }

}
